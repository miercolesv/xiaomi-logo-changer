Xiaomi Mi 10 (umi) boot logo: status
Made with xiaomi-logo-changer: https://github.com/miercolesv/xiaomi-logo-changer

Replaces the boot logo, the fastboot screen and the error screen.
For the Xiaomi Mi 10 (umi) only. Needs an unlocked bootloader.

1. Turn the phone off, then hold Volume down + Power until fastboot appears.
2. On the computer:
       fastboot flash logo logo.img
       fastboot reboot

To undo it, flash logo.img from the official fastboot ROM for your phone
(in the ROM's images folder), or your own backup of the logo partition.
