# xiaomi-logo-changer: writes new pictures into the logo partition.
# The original partition is saved first; removing the module restores it.
SKIPUNZIP=0
BK=/data/adb/xiaomi-logo-changer

find_part() {
  for d in /dev/block/by-name /dev/block/bootdevice/by-name; do
    for p in logo logo$(getprop ro.boot.slot_suffix); do
      [ -e "$d/$p" ] && { echo "$d/$p"; return; }
    done
  done
}

BLK=$(find_part)
[ -n "$BLK" ] || abort "! No logo partition found"
ui_print "- Logo partition: $BLK"

# Every slot must hold a picture of the expected size and format
while read -r off file len head; do
  [ -z "$off" ] && continue
  cur=$(dd if="$BLK" bs=1 skip="$off" count=30 2>/dev/null | od -An -tx1 | tr -d ' \n')
  [ "$cur" = "$head" ] || abort "! The logo partition is laid out differently on this phone; nothing was changed"
done < "$MODPATH/logo/slots.txt"

mkdir -p "$BK"
if [ ! -f "$BK/logo-original.img" ]; then
  dd if="$BLK" of="$BK/logo-original.img" bs=1048576 2>/dev/null || abort "! Could not save the original"
  ui_print "- Saved the original to $BK/logo-original.img"
fi
echo "$BLK" > "$BK/partition"

while read -r off file len head; do
  [ -z "$off" ] && continue
  dd if="$MODPATH/logo/$file" of="$BLK" bs=4096 seek=$((off / 4096)) conv=notrunc 2>/dev/null \
    || abort "! Writing $file failed; remove the module to restore the original"
  want=$(sha256sum "$MODPATH/logo/$file" | cut -d' ' -f1)
  got=$(dd if="$BLK" bs=4096 skip=$((off / 4096)) count=$(( (len + 4095) / 4096 )) 2>/dev/null | head -c "$len" | sha256sum | cut -d' ' -f1)
  [ "$want" = "$got" ] || abort "! $file did not verify; remove the module to restore the original"
  ui_print "- Wrote $file"
done < "$MODPATH/logo/slots.txt"

rm -f "$MODPATH"/logo/*.bmp
touch "$MODPATH/skip_mount"
ui_print "- Done. The new logo shows at the next restart."
ui_print "  Removing this module puts the original back."
