# Put the original logo partition back
BK=/data/adb/xiaomi-logo-changer
[ -f "$BK/logo-original.img" ] && [ -f "$BK/partition" ] && \
  dd if="$BK/logo-original.img" of="$(cat "$BK/partition")" bs=1048576 2>/dev/null && \
  rm -rf "$BK"
